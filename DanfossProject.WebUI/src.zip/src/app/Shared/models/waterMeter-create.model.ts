export class WaterMeterCreateModel {
    constructor (
        public SerialNumber: string,
        public CounterValue: number
    ) {}
}
