export class WaterMeter {
    constructor (
        public Id: number,
        public SerialNumber: string,
        public CounterValue: number
    ) {}
}
