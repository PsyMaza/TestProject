export interface Address {
    Country: string;
    City: string;
    ZIPCode: string;
    Street: string;
    HouseNumber: string;
}
