import { Injectable, OnDestroy } from '@angular/core';
import { BehaviorSubject, Subscription } from 'rxjs';
import { BuildingRepository } from '../repository/building.repository';
import { WaterMeterRepository } from '../repository/waterMeter.repository';
import { BuildigsTable } from '../../buildings/buildings.component';
import { BuildingCreateModel } from '../models/building-create.model';
import { Building } from '../models/building.model';
import { BuildingUpdateModel } from '../models/building-update.model';

@Injectable()
export class UpdateTableService {

    private buildingValue: Building;

    constructor(
        private buildingRepository: BuildingRepository,
        private waterMeterRepository: WaterMeterRepository
    ) {}

    private updateBuildingTableAttributesSource = new BehaviorSubject<Building>(this.buildingValue);
    updateBuildingTableAttribute = this.updateBuildingTableAttributesSource.asObservable();

    addValueToTable(value: BuildingCreateModel): void {
        this.buildingRepository.getBuildings()
        .subscribe(data => {
            const result = data.find(d => d.Address === value.Address);
            this.updateBuildingTableAttributesSource.next(result);
        });
    }

    updateValueToTable(value: BuildingUpdateModel): void {
        this.buildingRepository.getBuilding(value.Id)
            .subscribe(e => this.updateBuildingTableAttributesSource.next(e));
    }
}
